<html>
<head>
<title> SISTEM E-PERALATAN </title>

<style>

	.myButton {
				-moz-box-shadow:inset 13px 23px 50px -8px #276873;
				-webkit-box-shadow:inset 13px 23px 50px -8px #276873;
				box-shadow:inset 13px 23px 50px -8px #276873;
				background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #599bb3), color-stop(1, #408c99));
				background:-moz-linear-gradient(top, #599bb3 5%, #408c99 100%);
				background:-webkit-linear-gradient(top, #599bb3 5%, #408c99 100%);
				background:-o-linear-gradient(top, #599bb3 5%, #408c99 100%);
				background:-ms-linear-gradient(top, #599bb3 5%, #408c99 100%);
				background:linear-gradient(to bottom, #599bb3 5%, #408c99 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#599bb3', endColorstr='#408c99',GradientType=0);
				background-color:#599bb3;
				-moz-border-radius:34px;
				-webkit-border-radius:34px;
				border-radius:34px;
				border:2px solid #000000;
				display:inline-block;
				cursor:pointer;
				color:#ffffff;
				font-family:Trebuchet MS;
				font-size:19px;
				font-style:italic;
				padding:15px 17px;
				text-decoration:none;
				text-shadow:0px -1px 0px #3d768a;
			}

	.myButton:hover {
				background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #408c99), color-stop(1, #599bb3));
				background:-moz-linear-gradient(top, #408c99 5%, #599bb3 100%);
				background:-webkit-linear-gradient(top, #408c99 5%, #599bb3 100%);
				background:-o-linear-gradient(top, #408c99 5%, #599bb3 100%);
				background:-ms-linear-gradient(top, #408c99 5%, #599bb3 100%);
				background:linear-gradient(to bottom, #408c99 5%, #599bb3 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#408c99', endColorstr='#599bb3',GradientType=0);
				background-color:#408c99;
					}

	.myButton:active {
				position:relative;
				top:1px;
					}


body {
			background-color: black;
			background-image: url('img/3.png');
			background-size: 100%;
	 }




h1 {
            color: black;
            font-size: 50px;
            word-spacing: 10px;
            font-family: "algerian", arial, serif;
 			margin-top: 16%;
            margin-left:30%;
            text-shadow: 0 0 10px white, 0 0 20px white, 0 0 30px white, 0 0 40px white, 0 0 70px white, 0 0 80px white, 0 0 100px white, 0 0 150px white;
        }


 .right {
    background-color: lightblue;
    color: black;
    height: 12%;
    width: 30%;
    text-align: center;
    padding-left: 10px;
    margin-left: 50%;
    border: 3px solid blue;
    background: rgba(255,255,255); /* Fall-back for browsers that don't support rgba */
    background: rgba(255,255,255, 0.7);   
		}


	table {
		margin-left: 55%;
	}
	
	
  #footer {
            background-color: black;
            color: white;
            clear:both;
            text-align:center;
        }

</style>


    </head>

<body>

<center>
<h1> SISTEM E - PERALATAN <BR>
KOLEJ VOKASIONAL SHAH ALAM </h1> 
</center>

<h3>
<div class="right">
KOLEJ VOKASIONAL SHAH ALAM <br>
JALAN BATU TIGA, 40300 SHAH ALAM <br>
NO. TEL : 03-51916326 , NO FAKS : 03-51916325  <br>
EMEL : email@kvsa.edu.my <br>
</h3>
</div>


<br><br><br><br>

<table border="0">
<center>
<tr>
<form action="">
<th> <a href='pengguna/utama.php' class='mybutton'>PENGGUNA</a> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </th> 
<th> <a href='admin/index.php'  class='mybutton'>PENTADBIR</a>  </th>
</form>
</tr>
</table>

<br><br><br>
<center>
<div id="footer">

        <font color="white">  &copy; HAKCIPTA TERPELIHARA @ KOLEJ VOKASIONAL SHAH ALAM 2016</font>
    </div>

</center>

</body>
</html>
