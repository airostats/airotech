<html>
<head>
<title> SISTEM E-PERALATAN </title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<table border="0">
<tr>
<th>  <a href='utama.php' class="button"> PENGENALAN </button>   </th> 
<th>  <a href='senarai.php'  class="button"> SENARAI PERALATAN </button>  </th>
<th>  <a href='mohon.php'  class="button"> BORANG PERMOHONAN </button>  </th>
<th>  <a href='pulang.php'  class="button"> BORANG PULANGAN </button> </th>
<th>  <a href='semak.php'  class="button"> SEMAK PERMOHONAN </button>  </th>
</tr>
</table>


<div id="content" class="shadow">
<center> <h2> PENGENALAN </h2> </center>

<p>  &nbsp; &nbsp; &nbsp; Pada saat ini, sebahagian besar institusi pendidikan di negara kita tidak memiliki sistem yang membolehkan pengguna membuat pinjaman alat/barang secara online.
 Keadaan ini kurang efektif sehingga sebuah sistem dibina oleh individu dari Program Pangkalan Data dan Aplikasi Web iaitu  "SISTEM E-PERALATAN" dan mampu mengatasi masalah yang dihadapi semasa menggunakan sistem manual. 
 Secara umumnya, Sistem ini juga dicipta untuk memudahkan pensyarah untuk membuat pinjaman sesuatu barang dengan mudah. </p>

<p> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; "SISTEM E-PERALATAN" ini dibina agar dapat menangani kekangan serta kekurangan yang terdapat dalam sistem fail tradisional. 
Sistem ini dibina agar dapat mengurangkan masalah kehilangan barangan ict dan masalah pertindihan data dalam meminjam barangan ict.
 Sistem ini menawarkan proses pemantauan yang cekap, efektif dan berkesan. Diharapkan, dengan adanya sistem ini, semua peralatan 
 yang dipinjam dapat dikembalikan dan dapat menjalankan suatu program dengan jayanya </p>



<center>

<a href="senarai.php"><img src="img/link1.png" height="100px" width="200px"> </a>

&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

<a href="mohon.php"><img src="img/link2.png" height="100px" width="200px"> </a>

</center>


</div>

 <br>

<center>
<div id="footer">

        <font color="white">  &copy; HAKCIPTA TERPELIHARA @ KOLEJ VOKASIONAL SHAH ALAM 2016</font>
    </div>

</center>


</body>
</html>
