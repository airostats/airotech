<?php
$servername = "localhost";
$username = "zaimperalatan";
$password = "123abc";
$database = "eperalatan"; 


// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>


<html>
<head>
<title> SISTEM E-PERALATAN </title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<table border="0">
<tr>
<th>  <a href='utama.php' class="button"> PENGENALAN </button>   </th> 
<th>  <a href='senarai.php'  class="button"> SENARAI PERALATAN </button>  </th>
<th>  <a href='mohon.php'  class="button"> BORANG PERMOHONAN </button>  </th>
<th>  <a href='pulang.php'  class="button"> BORANG PULANGAN </button> </th>
<th>  <a href='semak.php'  class="button"> SEMAK PERMOHONAN </button>  </th>
</tr>
</table>



<div id="content" class="shadow">
<center>

<?php

//TEMPAT PENYAMBUNGAN NO IC DENGAN DATABASE SUPAYA NO IC SAMA //


$sql = "INSERT INTO pulang (No_Kakitangan, Nama_Pengguna, Peralatan)  
        
        VALUES ('".$_POST['nokakitangan']."', '".$_POST['namapengguna']."', '".$_POST['peralatan']."')" ;

{

if (mysqli_query($conn, $sql)) {
    echo "<br><br><br><br><br><br><br><br> <h3> Tahniah, Anda Telah Berjaya Memulangkan Peralatan Yang Di Pinjam. <br> Terima Kasih </h3>";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


 /*  echo  "
   
    <script>
        alert('New record created successfully') 
    </script>
    
        " ;

        */
} 
        
?>


<form action="">
<th> <a href='utama.php' class='mybutton'>HALAMAN UTAMA</a> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </th>
</form>

</center>

</div>


 <br>
 
<center>
<div id="footer">

        <font color="white">  &copy; HAKCIPTA TERPELIHARA @ KOLEJ VOKASIONAL SHAH ALAM 2016</font>
    </div>

</center>


</body>
</html>
