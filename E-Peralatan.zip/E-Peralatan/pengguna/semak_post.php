<?php
$servername = "localhost";
$username = "zaimperalatan";
$password = "123abc";
$database = "eperalatan"; 


// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>

<html>
<head>
<title> SISTEM E-PERALATAN </title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<table border="0">
<tr>
<th>  <a href='utama.php' class="button"> PENGENALAN </button>   </th> 
<th>  <a href='senarai.php'  class="button"> SENARAI PERALATAN </button>  </th>
<th>  <a href='mohon.php'  class="button"> BORANG PERMOHONAN </button>  </th>
<th>  <a href='pulang.php'  class="button"> BORANG PULANGAN </button> </th>
<th>  <a href='semak.php'  class="button"> SEMAK PERMOHONAN </button>  </th>
</tr>
</table>


<div id="content" class="shadow">
<center>

<h2> <u> SEMAK PERMOHONAN</u> PERALATAN ICT </h2>



 <?php

//connect to the database
mysql_connect ("localhost","zaimperalatan","123abc") or die ('Cannot connect to MySQL: ' . mysql_error());

//select database
mysql_select_db ("eperalatan") or die ('Cannot connect to the database: ' . mysql_error());


//variable
$ID=$_POST['ID'];

//query
$sql = "SELECT * FROM pinjaman WHERE ID='$ID' " ;

$records=mysql_query($sql) or die ('Query is invalid: ' . mysql_error());

?>

<center>
<table border="3">

<tr>
<th style="background-color: wheat; color: black; font-size: 25px; padding: 10px; font-weight: bold; text-align: center;"> <center> Nama Pengguna </th>
<th style="background-color: wheat; color: black; font-size: 25px; padding: 10px;  font-weight: bold; text-align: center;"> <center> Nama Peralatan</th>
<th style="background-color: wheat; color: black; font-size: 25px; padding: 10px; font-weight: bold; text-align: center;"> <center>Keputusan</th>
</tr></center>

<?php 
    while($row=mysql_fetch_assoc($records)) {

    echo '<tr>' ;

    echo '<td>' .$row["Nama_Pengguna"]. '</td>' ;
    
    echo '<td>' .$row["Peralatan"]. '</td>' ;

    echo '<td>' .$row["keputusan"]. '</td>' ;

    echo '</tr>' ;
    }

?>

</table>

<br>

<form action="">
<th> <a href='utama.php' class='mybutton'>HALAMAN UTAMA</a> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </th>
</form>

</center>

</div>


 <br>
 
<center>
<div id="footer">

        <font color="white">  &copy; HAKCIPTA TERPELIHARA @ KOLEJ VOKASIONAL SHAH ALAM 2016</font>
    </div>

</center>


</body>
</html>
