<html>
<head>
<title> SISTEM E-PERALATAN </title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<table border="0">
<tr>
<th>  <a href='utama.php' class="button"> PENGENALAN </button>   </th> 
<th>  <a href='senarai.php'  class="button"> SENARAI PERALATAN </button>  </th>
<th>  <a href='mohon.php'  class="button"> BORANG PERMOHONAN </button>  </th>
<th>  <a href='pulang.php'  class="button"> BORANG PULANGAN </button> </th>
<th>  <a href='semak.php'  class="button"> SEMAK PERMOHONAN </button>  </th>
</tr>
</table>



<div id="content" class="shadow">
<center>

<h2> <u> SEMAK PERMOHONAN</u> PERALATAN ICT </h2>

<form action="semak_post.php" method="post">

<table border="3">
<tr>
    <th style="background-color: wheat; color: black; font-size: 20px; padding: 5px; font-weight: bold; text-align: center;"> <p> No ID : </p></th>
    <td> <input type="text" name="ID" required> </td>
</tr>

<tr>
<th style="background-color: wheat; color: black; font-size: 20px; padding: 5px; font-weight: bold; text-align: center;"> <p> HANTAR / PADAM </th>
<td> <button type="submit" class="mybutton"> HANTAR </button> <button type="reset" class="mybutton"> PADAM </button> </td>
</tr>

</form>
</table>
</center>

</div>


 <br>
 
<center>
<div id="footer">

        <font color="white">  &copy; HAKCIPTA TERPELIHARA @ KOLEJ VOKASIONAL SHAH ALAM 2016</font>
    </div>

</center>


</body>
</html>
