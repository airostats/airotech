<?php
session_start();

if(!$_SESSION['username']){

  header('Location: index.php');
}
?>


<html>
<head>
<title> ADMIN SISTEM E-PERALATAN </title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<table border="0">
<tr>
<th>  <a href='utama.php' class="button"> UTAMA </button>   </th> 
<th>  <a href='tempah.php'  class="button"> SENARAI TEMPAHAN </button>  </th>
<th>  <a href='pulang.php'  class="button"> SENARAI PERMULANGAN </button>  </th>
<th>  <a href='alat.php'  class="button"> SENARAI PERALATAN</button> </th>
<th>  <a href='kemasadmin.php'  class="button"> KEMASKINI PENTADBIR</button> </th>
<th>  <a href='kemasalat.php'  class="button"> KEMASKINI PERALATAN</button> </th>
<th>  <a href='logout.php'  class="button"> LOG KELUAR </button>  </th>
</tr>
</table>

<br>

<div id="content" class="shadow">

<center>

<h2> SENARAI PENGGUNA YANG MEMBUAT TEMPAHAN : </h2>



<?php

//connect to the database
$server="localhost";
$username="zaimperalatan";
$password="123abc";
$db="eperalatan";

//CREATE CONNECTION

    $conn = new mysqli($server,$username,$password,$db);

//CHECK CONNECTION

    if($conn->connect_error) {
        die . ("Connection Failed :" . $conn->connect_error);
    }


$k=$_POST['id'];

$sql="UPDATE `pinjaman` SET `keputusan`='ya' WHERE `No_Kakitangan`='".$k."';";


if (mysqli_query($conn,$sql)) {
    echo "<br><center><h1><font face='Colonna MT'> ANDA BERJAYA KEMASKINI REKOD </font><h1></center>";
}

else {
    echo "Error : " . $sql . "<br>" . (mysqli_error($conn));
}

?>

<a href="utama.php" class="button"> HALAMAN UTAMA </a>

<center>



</table>
</center>


</div>

 <br><br>

<center>
<div id="footer">

        <font color="white">  &copy; HAKCIPTA TERPELIHARA @ KOLEJ VOKASIONAL SHAH ALAM 2016</font>
    </div>

</center>


</body>
</html>
