<?php
session_start();

if(!$_SESSION['username']){

  header('Location: index.php');
}
?>



<html>
<head>
<title> ADMIN SISTEM E-PERALATAN </title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<table border="0">
<tr>
<th>  <a href='utama.php' class="button"> UTAMA </button>   </th> 
<th>  <a href='tempah.php'  class="button"> SENARAI TEMPAHAN </button>  </th>
<th>  <a href='pulang.php'  class="button"> SENARAI PERMULANGAN </button>  </th>
<th>  <a href='alat.php'  class="button"> SENARAI PERALATAN</button> </th>
<th>  <a href='kemasadmin.php'  class="button"> KEMASKINI PENTADBIR</button> </th>
<th>  <a href='kemasalat.php'  class="button"> KEMASKINI PERALATAN</button> </th>
<th>  <a href='logout.php'  class="button"> LOG KELUAR </button>  </th>
</tr>
</table>

<br>

<div id="content" class="shadow">

<center>

<h2> SENARAI PERALATAN DI KVSA : </h2>

 <?php

//connect to the database
mysql_connect ("localhost","zaimperalatan","123abc") or die ('Cannot connect to MySQL: ' . mysql_error());

//select database
mysql_select_db ("eperalatan") or die ('Cannot connect to the database: ' . mysql_error());

//query
$sql = "SELECT * FROM peralatan" ;

$records=mysql_query($sql) or die ('Query is invalid: ' . mysql_error());

?>

<center>
<table border="3" style="margin: 4%;">

<tr>
<th style="background-color: wheat; color: black; font-size: 25px; padding: 10px; font-weight: bold; text-align: center;"> <center>Nama Peralatan</th>
<th style="background-color: wheat; color: black; font-size: 25px; padding: 10px;  font-weight: bold; text-align: center;"> <center>Kod Peralatan</th>
<th style="background-color: wheat; color: black; font-size: 25px; padding: 10px; font-weight: bold; text-align: center;"> <center>Status</th>
</tr>

<?php 
    while($row=mysql_fetch_assoc($records)) {

    echo '<tr>' ;

    echo '<td>' .$row["Nama"]. '</td>' ;
    
    echo '<td>' .$row["Kod"]. '</td>' ;

    echo '<td>' .$row["Status"]. '</td>' ;

    echo '</tr>' ;
    }

?>

</table>


<b>
<p style="color: red;"> STATUS :
0 (TIADA) 
1 (ADA)
</p>


</center>


</div>

 <br><br>

<center>
<div id="footer">

        <font color="white">  &copy; HAKCIPTA TERPELIHARA @ KOLEJ VOKASIONAL SHAH ALAM 2016</font>
    </div>

</center>


</body>
</html>
