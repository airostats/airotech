<?php
session_start();
$message="";
if(isset($_POST['submit'])) {
$conn = mysql_connect("localhost","root","");
mysql_select_db("eperalatan",$conn);
$result = mysql_query("SELECT * FROM pentadbiran WHERE username='" . $_POST["username"] . "' and password = '". $_POST["password"]."'");
$row  = mysql_fetch_array($result);


if($row > 0 ) {
$_SESSION["ID"] = $row[ID];
$_SESSION["username"] = $row[username];
header("Location:utama.php");
} 

else {
$message = "Invalid Username or Password!";
header("Location:index.php");
}
} 

?>


<html>
<head>
<title> SISTEM E-PERALATAN </title>

<style>

	.myButton {
				-moz-box-shadow:inset 13px 23px 50px -8px #276873;
				-webkit-box-shadow:inset 13px 23px 50px -8px #276873;
				box-shadow:inset 13px 23px 50px -8px #276873;
				background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #599bb3), color-stop(1, #408c99));
				background:-moz-linear-gradient(top, #599bb3 5%, #408c99 100%);
				background:-webkit-linear-gradient(top, #599bb3 5%, #408c99 100%);
				background:-o-linear-gradient(top, #599bb3 5%, #408c99 100%);
				background:-ms-linear-gradient(top, #599bb3 5%, #408c99 100%);
				background:linear-gradient(to bottom, #599bb3 5%, #408c99 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#599bb3', endColorstr='#408c99',GradientType=0);
				background-color:#599bb3;
				-moz-border-radius:34px;
				-webkit-border-radius:34px;
				border-radius:34px;
				border:2px solid #000000;
				display:inline-block;
				cursor:pointer;
				color:#ffffff;
				font-family:Trebuchet MS;
				font-size:15px;
				font-style:italic;
				padding:10px 16px;
				text-decoration:none;
				text-shadow:0px -1px 0px #3d768a;
			}

	.myButton:hover {
				background:-webkit-gradient(linear, left top, left bottom, color-stop(0.05, #408c99), color-stop(1, #599bb3));
				background:-moz-linear-gradient(top, #408c99 5%, #599bb3 100%);
				background:-webkit-linear-gradient(top, #408c99 5%, #599bb3 100%);
				background:-o-linear-gradient(top, #408c99 5%, #599bb3 100%);
				background:-ms-linear-gradient(top, #408c99 5%, #599bb3 100%);
				background:linear-gradient(to bottom, #408c99 5%, #599bb3 100%);
				filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#408c99', endColorstr='#599bb3',GradientType=0);
				background-color:#408c99;
					}

	.myButton:active {
				position:relative;
				top:1px;
					}


body {
			background-color: black;
			background-image: url('img/admin.png');
			background-size: 100%;
	 }




h1 {
            color: black;
            font-size: 10px;
            word-spacing: 10px;
            font-family: "algerian", arial, serif;
 			margin-top: 16%;
            text-align: center;
    }


p {
		font-family: "Cooper Black", arial, san-serif;
		font-size: 20px;
	}


.right {
		height: 39%;
		width: 45%;
		text-align: center;
		padding-left: 40px;
		margin-left: 50%;
		margin-top: 16%;
		background: rgba(255,255,255); /* Fall-back for browsers that don't support rgba */
   		background: rgba(255,255,255, 0.7);

	}

	table {
		margin-left: 55%;
	}
	
	
  #footer {
            background-color: black;
            color: white;
            clear:both;
            text-align:center;
        }

</style>


    </head>

<body>


<div class="right">
<h1><font face="algerian" size="7px"> SISTEM E-PERALATAN </h1></font> 
<h3> <font face="Colonna MT" size="6px">  PENTADBIR </h3></font>



<form action="" method="POST">

<p> Username :
<input type="text" name="username" required> <br>


<p> Password :
<input type="password" name="password" required>  <br><br>

<button type="submit" name="submit" class="mybutton"> LOG MASUK </button>

</h1>
</form>
</div>

<br><br><br><br>

<center>
<div id="footer">

        <font color="white">  &copy; HAKCIPTA TERPELIHARA @ KOLEJ VOKASIONAL SHAH ALAM 2016</font>
    </div>

</center>

</body>
</html>
