
<?php
session_start();

if(!$_SESSION['username']){

  header('Location: index.php');
}
?>



<html>
<head>
<title> ADMIN SISTEM E-PERALATAN </title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<table border="0">
<tr>
<th>  <a href='utama.php' class="button"> UTAMA </button>   </th> 
<th>  <a href='tempah.php'  class="button"> SENARAI TEMPAHAN </button>  </th>
<th>  <a href='pulang.php'  class="button"> SENARAI PERMULANGAN </button>  </th>
<th>  <a href='alat.php'  class="button"> SENARAI PERALATAN</button> </th>
<th>  <a href='kemasadmin.php'  class="button"> KEMASKINI PENTADBIR</button> </th>
<th>  <a href='kemasalat.php'  class="button"> KEMASKINI PERALATAN</button> </th>
<th>  <a href='logout.php'  class="button"> LOG KELUAR </button>  </th>
</tr>
</table>

<br>

<div id="content" class="shadow">

<center>

<h2> KEMASKINI PENTADBIR  : </h2>

</center>

<div class="first">

<center>

<br>

<h3 style="font-size: 25px;"> TAMBAH PENTADBIR </h3>

<form action="kemasadmin_config.php" method="POST">
<table border="3">

<tr>
  <td style="background-color: wheat; color: black; font-size: 25px; padding: 10px; font-weight: bold; text-align: center;"> Nama Pentadbir : </td>
  <td> <input type="text" name="username"  required> </td>
</tr>

<tr>
  <td style="background-color: wheat; color: black; font-size: 25px; padding: 10px; font-weight: bold; text-align: center;"> Password : </td>
  <td> <input type="password" name="password" required> </td>
</tr>


</table>

<button type="submit" class="button"> SUBMIT </button>

</form>

</center>

</div>


<div class="third">

<center>

<h3 style="font-size: 25px;"> DELETE PENTADBIR </h3>


<?php
$server="localhost";
$username="root";
$password="";
$db="eperalatan";

//CREATE CONNECTION

  $conn = new mysqli($server,$username,$password,$db);

//CHECK CONNECTION
  
  if ($conn->connect_error) {
    die . ("Connection Failed" . $conn->connect_error);
  }

  if (isset($_GET['username'])) {
    $username=$_GET['username'];
  }
// variable 

$sql = "DELETE FROM eperalatan.pentadbiran WHERE pentadbiran.username='$username' " ;

{

if (mysqli_query($conn, $sql)) {
    echo "<br><br><br><br><center><h1><font face='Colonna MT'> ANDA BERJAYA PADAM REKOD </font><h1></center>";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);



 /*  echo  "
   
  <script>
    alert('New record created successfully') 
  </script>
  
    " ;

    */
} 
    
?>

<a href="utama.php" class="button"> HALAMAN UTAMA </a>
</html>
    </center>
</center>

</table>


</div>
</div>


 <br><br>

<center>
<div id="footer">

        <font color="white">  &copy; HAKCIPTA TERPELIHARA @ KOLEJ VOKASIONAL SHAH ALAM 2016</font>
    </div>

</center>


</body>
</html>
