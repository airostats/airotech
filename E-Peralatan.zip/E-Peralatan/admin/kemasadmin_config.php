<?php
session_start();

if(!$_SESSION['username']){

  header('Location: index.php');
}
?>



<html>
<head>
<title> ADMIN SISTEM E-PERALATAN </title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<table border="0">
<tr>
<th>  <a href='utama.php' class="button"> UTAMA </button>   </th> 
<th>  <a href='tempah.php'  class="button"> SENARAI TEMPAHAN </button>  </th>
<th>  <a href='pulang.php'  class="button"> SENARAI PERMULANGAN </button>  </th>
<th>  <a href='alat.php'  class="button"> SENARAI PERALATAN</button> </th>
<th>  <a href='kemasadmin.php'  class="button"> KEMASKINI PENTADBIR </button> </th>
<th>  <a href='kemasalat.php'  class="button"> KEMASKINI PERALATAN </button> </th>
<th>  <a href='logout.php'  class="button"> LOG KELUAR </button>  </th>
</tr>
</table>

<br>

<div id="content" class="shadow">

<center>

<h2> KEMASKINI PENTADBIR  : </h2>

</center>


<div class="first">


<?php
$server="localhost";
$username="root";
$password="";
$db="eperalatan";

//CREATE CONNECTION

	$conn = new mysqli($server,$username,$password,$db);

//CHECK CONNECTION
	
	if ($conn->connect_error) {
		die . ("Connection Failed" . $conn->connect_error);
	}

//VARIABLES

$username=$_POST['username'];
$password=$_POST['password'];

//SQL

$sql="INSERT INTO pentadbiran (username,password)
		VALUES ('$username','$password')";


if (mysqli_query($conn,$sql)) {
	echo "<br><br><br><br><center><h1><font face='Colonna MT'> ANDA BERJAYA MEMASUKKAN REKOD BAHARU </font><h1></center>";
}

else {
	echo "Error : " . $sql . "<br>" . (mysqli_error($conn));
}

mysqli_close($conn) ;

?>

<a href="utama.php" class="button"> HALAMAN UTAMA </a>

</center>
</div>



</center>

</div>

<div class="third">

<center>

<h3 style="font-size: 25px;"> DELETE PENTADBIR </h3>



<?php
$server="localhost";
$username="root";
$password="";
$db="eperalatan";

//CREATE CONNECTION

  $conn = new mysqli($server,$username,$password,$db);

//CHECK CONNECTION
  
  if ($conn->connect_error) {
    die . ("Connection Failed" . $conn->connect_error);
  }



            $sql="SELECT username FROM pentadbiran";
                  
            mysql_select_db($db);

            $result=$conn->query($sql);
            ?>
            <center>
            <table border="3">
                <tr>
                    <th style="background-color: wheat; color: black; font-size: 25px; padding: 10px; font-weight: bold; text-align: center;">Username</th>
                </tr>
                <tr>

            <?php

            if ($result->num_rows > 0) {
             while($row = $result->fetch_assoc()) {
                echo 
                "
                    <td>".$row['username']."</td>
                    <td><a href=\"deleteadmin.php?username={$row['username']}\">Delete</a></td></tr>";
                }

            }
            else{
                echo "<td colspan='8'>Tiada data</td>";
            }
        ?>
            
        </table>
    </center>
</center>

</table>

</div>
</div>

 <br><br>

<center>
<div id="footer">

        <font color="white">  &copy; HAKCIPTA TERPELIHARA @ KOLEJ VOKASIONAL SHAH ALAM 2016</font>
    </div>

</center>


</body>
</html>
