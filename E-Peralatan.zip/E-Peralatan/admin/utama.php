<?php
session_start();

if(!$_SESSION['username']){

  header('Location: index.php');
}
?>


<html>
<head>
<title> ADMIN SISTEM E-PERALATAN </title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<table border="0">
<tr>
<th>  <a href='utama.php' class="button"> UTAMA </button>   </th> 
<th>  <a href='tempah.php'  class="button"> SENARAI TEMPAHAN </button>  </th>
<th>  <a href='pulang.php'  class="button"> SENARAI PERMULANGAN </button>  </th>
<th>  <a href='alat.php'  class="button"> SENARAI PERALATAN</button> </th>
<th>  <a href='kemasadmin.php'  class="button"> KEMASKINI PENTADBIR</button> </th>
<th>  <a href='kemasalat.php'  class="button"> KEMASKINI PERALATAN</button> </th>
<th>  <a href='logout.php'  class="button"> LOG KELUAR </button>  </th>
</tr>
</table>

<br>

<div id="content" class="shadow">

<center>

<br><br><br>

<h3> HI ADMIN ! <br><br> SELAMAT DATANG KE RUANG PENTADBIRAN SISTEM E - PERALATAN <br><br> KVSA </h3>

</center>


</div>

 <br><br>

<center>
<div id="footer">

        <font color="white">  &copy; HAKCIPTA TERPELIHARA @ KOLEJ VOKASIONAL SHAH ALAM 2016</font>
    </div>

</center>


</body>
</html>
